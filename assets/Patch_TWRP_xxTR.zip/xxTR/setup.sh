### Variables and Setup

# begin variables
unxz=$home/xxTR/unxz
# end variables

# set permissions
chmod +x $unxz

# begin boot extract
$unxz -f -T0 $home/Kernel.tar.xz
# end boot extract