### Variables and Setup

# begin kernel changes
device_name=$(file_getprop /default.prop ro.product.device);

tar xf $home/Kernel.tar Kernel/$device_name/zImage
tar xf $home/Kernel.tar Kernel/$device_name/dtb.img
rm -rf $home/Kernel.tar

mv -f Kernel/$device_name/zImage $home/Image;
mv -f Kernel/$device_name/dtb.img $split_img/extra;
rm -rf Kernel

ui_print "Reboot To Recovery Again After Doing This";
# end kernel changes