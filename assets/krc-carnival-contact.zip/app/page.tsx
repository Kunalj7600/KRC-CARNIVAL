import ContactPage from "@/components/contact-page"

export default function Home() {
  return <ContactPage />
}
